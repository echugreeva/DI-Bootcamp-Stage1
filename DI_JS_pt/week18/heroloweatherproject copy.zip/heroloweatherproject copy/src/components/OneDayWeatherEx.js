const OneDaysEx = [
    {
      "LocalObservationDateTime": "2022-11-02T18:32:00+01:00",
      "EpochTime": 1667410320,
      "WeatherText": "Cloudy",
      "WeatherIcon": 7,
      "HasPrecipitation": false,
      "PrecipitationType": null,
      "IsDayTime": false,
      "Temperature": {
        "Metric": {
          "Value": 14.2,
          "Unit": "C",
          "UnitType": 17
        },
        "Imperial": {
          "Value": 58,
          "Unit": "F",
          "UnitType": 18
        }
      },
      "MobileLink": "http://www.accuweather.com/en/fr/paris/623/current-weather/623?lang=en-us",
      "Link": "http://www.accuweather.com/en/fr/paris/623/current-weather/623?lang=en-us"
    }
  ]

  export default OneDaysEx